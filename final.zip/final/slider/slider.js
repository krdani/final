 const slides = document.getElementsByClassName("slide");
    let i = 0;
    const next = document.getElementsByClassName("slider-next")[0];
   const prev = document.getElementsByClassName('slider-prev')[0];
      
     next.onclick = increase;
     prev.onclick = decrease;
    const paginations = document.getElementsByClassName("slider-pagination-page");
      
    for(let page=0;page<paginations.length;page++){
      
        paginations[page].onclick = ()=>show(page);
        
    }  
      
      
      show(0);
      function increase(){
          console.log("hi")
          i++;
          if(i==3) i=0;
          show(i);
          
      }
      
      function decrease(){
          i--;
          if(i==-1) i=2;
          show(i);
          
      }
    function show(index){
        
           for(let l=0;l<slides.length;l++)
          {
              
            slides[l].style.display="none";
           }
      
      slides[index].style.display="flex";
      
  } 
      
       